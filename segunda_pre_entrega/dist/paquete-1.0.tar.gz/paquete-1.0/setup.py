from setuptools import setup

setup(
    name="paquete",
    version="1.0",
    description="Paquete redistribuible para la segunda pre-entrega",
    author="Irina Meroi",
    author_email="irimeroi7@gmail.com",
    
    packages=["paquete"]
)